﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.IO;
using System.Drawing;
using System.ComponentModel;
using System.Text.RegularExpressions;
using System.Security.Permissions;                      //包含为制作类似DoEvent函数的DispatcherHelper类库。
using System.Windows.Threading;                         //包含时钟中断，DispatcherTimer。
using System.Threading;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace WpfGridFileView
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>用于选择读入数据文件的路径</summary>
        public static Microsoft.Win32.OpenFileDialog opfd = new Microsoft.Win32.OpenFileDialog();
        /// <summary>定义了图像和一些全程变量</summary>
        System.Drawing.Bitmap theBitmap;
        /// <summary>记忆启动程序的目录,要求连带的动态链接库,数据库必须与应用程序同目录.</summary>
        string curDir;
        /// <summary>设定一个经纬网格数据类</summary>
        CommonGridDat.CommonGridDat curGridBase;
        /// <summary>设定当前经纬网格数据所在路径</summary>
        string curDataPath;
        /// <summary>保存当前经纬网格数据文件名</summary>
        string curDataFile;
        /// <summary>记录当前数据目录文件名列表</summary>
        List<string> curPathFiles;
        /// <summary>记录当前数据文件名在文件名列表中的位置</summary>
        int indexCurFile;
        /// <summary>设置一个文件名识别的正则表达式</summary>
        public Regex regFileName;
        /// <summary>设置一个bool量，表达当前显示的图像像素是否带着经纬网格</summary>
        bool ifGrid;
        /// <summary>设置一个bool量，记录当前读入的文件是否压缩文件，true:压缩，false:非压缩。</summary>
        bool fileCompressID;

        /// <summary>设定一个内存流，用于指向图像控件的源</summary>
        MemoryStream memStream;
        /// <summary>显示用图像源</summary>
        ImageSource bmpSource;
        /// <summary>显示用图像源转换格式</summary>
        ImageSourceConverter imgSourCon;

        /// <summary>记录鼠标左键按下事件。</summary>
        private bool mouseDown;
        /// <summary>记录鼠标左键按下后的坐标</summary>
        private System.Windows.Point mouseXY;
        /// <summary>记录鼠标右键按下的坐标</summary>
        private System.Windows.Point msRightXY;
        /// <summary>用于图像ToolTip绑定的文本</summary>
        ViewTxt strImgTips;
        /// <summary>定义图像ToolTip与相应文本的绑定</summary>
        System.Windows.Data.Binding imgTipBindings;

        /// <summary>设置一个bool量，表达当前是否处于动画状态</summary>
        bool bAnim;
        /// <summary>定义了当前参与动画的数据图像</summary>
        System.Drawing.Bitmap[] theBitmaps;
        /// <summary>设定相应参与动画的内存流，用于指向图像控件的源</summary>
        MemoryStream[] theBitmapStreams;
        /// <summary>相应参与动画的显示用图像源</summary>
        ImageSource[] thebmpSources;
        /// <summary>相应参与动画的显示用图像源转换格式</summary>
        ImageSourceConverter[] theimgSourCons;
        /// <summary>设置滚动播放显示的时间中断</summary>
        DispatcherTimer timer = new DispatcherTimer();
        /// <summary>设置一个计数，记录当前滚动播放的数据图片排序。</summary>
        int animIndex;
        /// <summary>设置一个计数，记录当前参与滚动播放的数据图片总数。这个值的极限暂定20。</summary>
        int animNum;
        /// <summary>设置一个计时，专门用于动画检测，以保证当前滚动显示的动画是最新画面。</summary>
        DateTime dtAnimUpdate;

        /// <summary>
        /// 随窗口初始化一些必要的变量。
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            curDir = Environment.CurrentDirectory;
            curDataPath = curDir;
            fileCompressID = false;

            strImgTips = new ViewTxt();
            imgTipBindings = new System.Windows.Data.Binding();
            imgTipBindings.Source = strImgTips;                     //定义好这个窗口图像控件的ToolTip字符串，以便后用。
            imgTipBindings.Path = new PropertyPath("txtLongStr");
            BindingOperations.SetBinding(this.BackFrame, System.Windows.Controls.Image.ToolTipProperty, imgTipBindings);

            curPathFiles = new List<string>();
            regFileName = new Regex(@"Channel\d{16}-(05|10|20|50).Grd");
            ifGrid = false;

            timer.Tick += new EventHandler(animationUpdate);
            timer.Interval = TimeSpan.FromSeconds(1);   //设置刷新的间隔时间
            timer.Stop();
            animIndex = 0;
            bAnim = false;

        }

        /// <summary>
        /// 读入一个经纬网格数据文件，并显示其第一层，默认第一层为灰度层。
        /// </summary>
        private void btnReadFrom_Click(object sender, RoutedEventArgs e)
        {
            string fileNameTmp = "";
            opfd.InitialDirectory = curDataPath;
            //opfd.DefaultExt = "Grd";
            opfd.Filter = "Grid Files(*.Grd;*.grd);Grid ComPressFiles(*.Grd.Zip;*.grd.zip)|*.Grd;*.grd;*.Grd.Zip;*.grd.zip";
            opfd.Title = "这个程序装载过程需要一个.Grd或.Grd.Zip文件";
            if (opfd.ShowDialog() == true)
            {
                Cursor tmpMouse = Mouse.OverrideCursor;
                Mouse.OverrideCursor = Cursors.Wait;
                btnAnimation.IsEnabled = false;
                btnLeft.IsEnabled = false;
                btnReadFrom.IsEnabled = false;
                btnReturn.IsEnabled = false;
                btnRight.IsEnabled = false;
                txtDiscribe.Text = "请稍候！。。。。。。" + "\r\n" + txtDiscribe.Text;

                fileNameTmp = opfd.FileName;
                if (fileNameTmp != "")
                {
                    if ((fileNameTmp.Contains("Channel")) && (fileNameTmp.Contains(".Grd.Zip") || fileNameTmp.Contains(".grd.zip")))
                    {
                        regFileName = new Regex(@"Channel\d{16}-(05|10|20|50).Grd.Zip");
                        fileCompressID = true;
                    }       //成像仪光谱通道数据，压缩格式。
                    else if ((fileNameTmp.Contains("Channel")) && (fileNameTmp.Contains(".Grd") || fileNameTmp.Contains(".grd")))
                    {
                        regFileName = new Regex(@"Channel\d{16}-(05|10|20|50).Grd");
                        fileCompressID = false;
                    }       //成像仪光谱通道数据，非压缩格式。
                    //else if ((fileNameTmp.Contains("ZAGangle")) && (fileNameTmp.Contains(".Grd.Zip") || fileNameTmp.Contains(".grd.zip")))
                    //{
                    //    regFileName = new Regex(@"ZAGangle\d{16}-(05|10|20|50).Grd.Zip");
                    //    fileCompressID = true;
                    //}       //成像仪天顶、方位等角度数据，压缩格式。
                    //else if ((fileNameTmp.Contains("ZAGangle")) && (fileNameTmp.Contains(".Grd") || fileNameTmp.Contains(".grd")))
                    //{
                    //    regFileName = new Regex(@"ZAGangle\d{16}-(05|10|20|50).Grd");
                    //    fileCompressID = false;
                    //}       //成像仪天顶、方位等角度数据，非压缩格式。        //以上被注释这一段用于测试天顶角、方位角等的正确性。
                    else
                    {
                        txtDiscribe.Text = "文件选择不正确，不是本程序处理的数据文件！！！" + txtDiscribe.Text;
                        Mouse.OverrideCursor = tmpMouse;
                        btnAnimation.IsEnabled = true;
                        btnLeft.IsEnabled = true;
                        btnReadFrom.IsEnabled = true;
                        btnReturn.IsEnabled = true;
                        btnRight.IsEnabled = true;
                        return;
                    }    //根据用户选择的文件，重新调整文件名识别正则表达式。
                    curDataPath = System.IO.Path.GetDirectoryName(fileNameTmp);
                    string[] thePathFiles = Directory.GetFiles(curDataPath);
                    Array.Sort(thePathFiles);
                    Match matchFilename;
                    curPathFiles.Clear();
                    foreach (string strFileName in thePathFiles)
                    {
                        matchFilename = regFileName.Match(strFileName);
                        if (matchFilename.Success)
                        {
                            curPathFiles.Add(strFileName);
                            if (strFileName == fileNameTmp) indexCurFile = curPathFiles.Count - 1;
                        }
                    }               //上面这一段将用户选定目录下的所有.Grd或.Grd.Zip文件名全部添加进当前文件名列表当中，以备来回滚动播放。
                    curDataFile = fileNameTmp;

                    FileInfo basefileinfo = new FileInfo(fileNameTmp);
                    //IFormatter baseFormat = new BinaryFormatter();
                    //Stream basestream;
                    bool bReadOk = true;
                    Object tmpObj;
                    curGridBase = new CommonGridDat.CommonGridDat();
                    if (basefileinfo.Exists)
                    {
                        try
                        {
                            if (fileCompressID)
                            {
                                bReadOk = curGridBase.ReadFromCompressFile(ref fileNameTmp, out tmpObj);
                            }
                            else
                            {
                                bReadOk = curGridBase.ReadFromFile(ref fileNameTmp, out tmpObj);
                            }
                            curGridBase = (CommonGridDat.CommonGridDat)tmpObj;
                            //basestream = new FileStream(fileNameTmp, FileMode.Open, FileAccess.Read, FileShare.Read);
                            //curGridBase = (CommonGridDat.CommonGridDat)baseFormat.Deserialize(basestream);
                            //basestream.Close();
                        }
                        catch (Exception ecpt)
                        {
                            txtDiscribe.Text = "数据文件导入出错，有可能数据分辨率不匹配。错误码：" + ecpt.Message + "\r\n" + txtDiscribe.Text;
                            Mouse.OverrideCursor = tmpMouse;
                            btnAnimation.IsEnabled = true;
                            btnLeft.IsEnabled = true;
                            btnReadFrom.IsEnabled = true;
                            btnReturn.IsEnabled = true;
                            btnRight.IsEnabled = true;
                            return;
                        }
                        ifGrid = false;         //刚读出来的数据肯定不带网格，因此要对此标志明确赋值。

                        int levelTmp = 0;
                        curGridBase.MakeTheLevelImage(ref levelTmp, out theBitmap);
                        bool bGrd = (bool)grdLine.IsChecked;
                        addGridSub(bGrd);
                    }
                    else
                    {
                        txtDiscribe.Text = "选定文件有问题，失败！！！" + "\r\n" + txtDiscribe.Text;
                    }
                }
                else
                {
                    txtDiscribe.Text = "选定文件有问题，失败！！！" + "\r\n" + txtDiscribe.Text;
                }

                Mouse.OverrideCursor = tmpMouse;
                btnAnimation.IsEnabled = true;
                btnLeft.IsEnabled = true;
                btnReadFrom.IsEnabled = true;
                btnReturn.IsEnabled = true;
                btnRight.IsEnabled = true;
            }

        }

        /// <summary>
        /// 图像容器的左击鼠标事件，用于处理图像在容器中的移动始。
        /// </summary>
        private void BackFrame_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Shapes.Rectangle img = sender as System.Windows.Shapes.Rectangle;
            if (img == null)
            {
                return;
            }
            img.CaptureMouse();
            mouseDown = true;
            mouseXY = e.GetPosition(img);
        }

        /// <summary>
        /// 图像容器的左击鼠标事件，用于处理图像在容器中的移动终。
        /// </summary>
        private void BackFrame_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Shapes.Rectangle img = sender as System.Windows.Shapes.Rectangle;
            if (img == null)
            {
                return;
            }
            img.ReleaseMouseCapture();
            mouseDown = false;

            viewImgLL.Visibility = System.Windows.Visibility.Hidden;     //如果左键鼠标启动，则停止右键提取显示数据的操作。
            strImgTips.txtLongStr = "";

        }

        /// <summary>
        /// 处理用于处理图像在容器中的移动。
        /// </summary>
        private void BackFrame_MouseMove(object sender, MouseEventArgs e)
        {
            System.Windows.Shapes.Rectangle img = sender as System.Windows.Shapes.Rectangle;
            if (img == null)
            {
                return;
            }
            if (mouseDown)
            {
                Domousemove(img, e);
            }
        }

        /// <summary>
        /// 是处理图像在容器中的移动的子程序，即：专门配合BackFrame_MouseMove(.....)
        /// </summary>
        /// <param name="img">传递过来的容器控件</param>
        /// <param name="e">传递过来的鼠标参数</param>
        private void Domousemove(System.Windows.Shapes.Rectangle img, MouseEventArgs e)
        {
            if (e.LeftButton != MouseButtonState.Pressed)
            {
                return;
            }
            TransformGroup group = Grid0.FindResource("ImgMagTrans") as TransformGroup;
            //Debug.Assert(group != null);
            TranslateTransform transform = group.Children[1] as TranslateTransform;
            System.Windows.Point position = e.GetPosition(img);
            ScaleTransform transform0 = group.Children[0] as ScaleTransform;
            double xScale = transform0.ScaleX;
            double parentH = img.ActualHeight;
            double parentW = img.ActualWidth;
            double yCount = parentH * xScale;
            double xCount = parentW * xScale;
            double xRight = parentW - xCount;
            double yBottom = parentH - yCount;
            double diffX = position.X - mouseXY.X;
            double diffY = position.Y - mouseXY.Y;
            if (((transform.X + diffX) < xRight) || ((transform.X + diffX) > 0))
                transform.X += 0;
            else
                transform.X += diffX;              // m_PreviousMousePoint.X;

            if (((transform.Y + diffY) < yBottom) || ((transform.Y + diffY) > 0))
                transform.Y += 0;
            else
                transform.Y += diffY;              // m_PreviousMousePoint.Y;
            mouseXY = position;

        }

        /// <summary>
        /// 图像容器的鼠标滚轴事件，用于处理图像在容器中的放大和缩小。
        /// </summary>
        /// <param name="sender">图像容器控件</param>
        /// <param name="e">图像容器鼠标事件参数</param>
        private void BackFrame_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            System.Windows.Shapes.Rectangle img = sender as System.Windows.Shapes.Rectangle;
            if (img == null)
            {
                return;
            }
            System.Windows.Point point = e.GetPosition(img);
            TransformGroup group = Grid0.FindResource("ImgMagTrans") as TransformGroup;      //放大缩小函数
            double delta = e.Delta * 0.001;        //传递过来的鼠标滚轴系数，由于太大，缩小其千分之一为放大倍数。
            DowheelZoom(group, point, delta);   //具体缩放操作，调用子程序。

            DoCorrectZoom(img, e);      //这个子程序主要是修正因放大缩小过程造成图像收进容器以内的情况，由于限定图像缩小最小为1，也即初始填充容器的尺度。

        }

        /// <summary>
        /// 用于处理图像在容器中的放大和缩小的具体操作的子程序，即：与BackFrame_MouseWheel协同的子程序。
        /// </summary>
        private void DowheelZoom(TransformGroup group, System.Windows.Point point, double delta)
        {
            System.Windows.Point pointToContent = group.Inverse.Transform(point);
            ScaleTransform transform = group.Children[0] as ScaleTransform;
            if ((transform.ScaleX + delta < 1) || (transform.ScaleX + delta > 8)) return;
            transform.ScaleX += delta;
            transform.ScaleY += delta;
            TranslateTransform transform1 = group.Children[1] as TranslateTransform;
            transform1.X = -1 * ((pointToContent.X * transform.ScaleX) - point.X);
            transform1.Y = -1 * ((pointToContent.Y * transform.ScaleY) - point.Y);
        }

        /// <summary>
        /// 用于处理图像在放大和缩小后，图像与容器可能出现的偏差的子程序，即：与BackFrame_MouseWheel协同的子程序。
        /// </summary>
        private void DoCorrectZoom(System.Windows.Shapes.Rectangle img, MouseEventArgs e)
        {
            TransformGroup group = Grid0.FindResource("ImgMagTrans") as TransformGroup;
            TranslateTransform transform = group.Children[1] as TranslateTransform;
            var transform0 = group.Children[0] as ScaleTransform;
            double xScale = transform0.ScaleX;
            double parentH = img.ActualHeight;
            double parentW = img.ActualWidth;       //容器的实际尺寸。
            double yCount = parentH * xScale;
            double xCount = parentW * xScale;       //图像缩放后的尺寸。
            double xRight = parentW - xCount;
            double yBottom = parentH - yCount;      //图像、容器右、下边界重合时的最大坐标差。左、上的最大坐标差当然是0。
            double diffX = transform.X;
            double diffY = transform.Y;
            //以下判断图像与容器是否出现了左、上边界移入容器内，或者右、下边界移入容器内的情况，如有，则移动使边界合一。基本依据是图像缩小系数最小为1。
            if (diffX > 0)
                transform.X -= diffX;
            else if (diffX < xRight)
                transform.X -= (diffX - xRight);
            if (diffY > 0)
                transform.Y -= diffY;
            else if (diffY < yBottom)
                transform.Y -= (diffY - yBottom);
        }

        /// <summary>
        /// 处理右键鼠标事件，在图像上以ToolTip形式显示对应数据值
        /// </summary>
        private void BackFrame_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Shapes.Rectangle img = sender as System.Windows.Shapes.Rectangle;
            msRightXY = e.GetPosition(img);
            datEllPt.Center = new System.Windows.Point(msRightXY.X, msRightXY.Y);
            viewImgLL.Visibility = System.Windows.Visibility.Visible;

            TransformGroup group = Grid0.FindResource("ImgMagTrans") as TransformGroup;      //放大缩小函数
            TranslateTransform transform = group.Children[1] as TranslateTransform;
            ScaleTransform transform0 = group.Children[0] as ScaleTransform;
            double xScale = transform0.ScaleX;
            double parentH = img.ActualHeight;
            double parentW = img.ActualWidth;
            double originalH = theBitmap.Height;
            double originalW = theBitmap.Width;
            System.Windows.Point origPoint = group.Inverse.Transform(msRightXY);
            double coeffH = originalH / parentH;
            double coeffW = originalW / parentW;
            int colNum = (int)(origPoint.X * coeffW);
            double colValue = colNum * curGridBase.dEndlongRes + curGridBase.dWLon;
            int rowNum = (int)(origPoint.Y * coeffH);
            double rowValue = curGridBase.dTLat - rowNum * curGridBase.dCrossRes;

            strImgTips.txtLongStr = "纬度：" + rowValue.ToString() + "  经度：" + colValue.ToString() + "  灰度：" + curGridBase.iLLGrid[rowNum, colNum, 0].ToString()
                + "   参数：" + curGridBase.iLLGrid[rowNum, colNum, 1].ToString();
        }

        /// <summary>
        /// 处理图像加载经纬标志点线的请求事件
        /// </summary>
        private void grdLine_Click(object sender, RoutedEventArgs e)
        {
            bool bChoice = (bool)grdLine.IsChecked;
            addGridSub(bChoice);
        }

        /// <summary>
        /// 设一个带加线的显示图像子程序，简化代码。
        /// </summary>
        /// <param name="bGrd"></param>
        private void addGridSub(bool bGrd)
        {
            if (ifGrid != bGrd)
            {
                System.Drawing.Color coPix;
                byte bpix;
                int ixBegin = (int)curGridBase.dWLon;
                int iyBegin = (int)curGridBase.dTLat;
                int ixEnd = (int)curGridBase.dELon;
                int iyEnd = (int)curGridBase.dBLat;
                int iDifx = ixEnd - ixBegin;
                int iDify = iyBegin - iyEnd;
                int bmpHeight = theBitmap.Height;
                int bmpWidth = theBitmap.Width;
                double coeffx = bmpWidth / iDifx;
                double coeffy = bmpHeight / iDify;
                int iTmpX = 0;
                int iTmpY = 0;
                for (int iy = iyBegin; iy > iyEnd; iy--)
                {
                    for (int ix = ixBegin; ix < ixEnd; ix++)
                    {
                        iTmpX = (int)((ix - ixBegin) * coeffx);
                        iTmpY = (int)((iyBegin - iy) * coeffy);
                        coPix = theBitmap.GetPixel(iTmpX, iTmpY);
                        bpix = coPix.R;
                        if (bGrd)
                            coPix = System.Drawing.Color.FromArgb(bpix, 0, bpix);
                        else
                            coPix = System.Drawing.Color.FromArgb(bpix, bpix, bpix);
                        theBitmap.SetPixel(iTmpX, iTmpY, coPix);
                    }
                }
                ifGrid = bGrd;          //图是否带网格标志在这里要确定。
            }

            memStream = new MemoryStream();
            imgSourCon = new ImageSourceConverter();
            theBitmap.Save(memStream, System.Drawing.Imaging.ImageFormat.Png);
            bmpSource = (ImageSource)imgSourCon.ConvertFrom(memStream);
            viewImg0.Source = bmpSource;

            int level = 0;
            txtDiscribe.Text = curGridBase.gDataDiscr[level].DataDiscr + "\r\n年月日：" + curGridBase.gDataDiscr[level].DYear.ToString() + "-" +
                curGridBase.gDataDiscr[level].DMounth.ToString() + "-" + curGridBase.gDataDiscr[level].DDay.ToString() + "\r\n时分秒：" +
                curGridBase.gDataDiscr[level].DTime.ToString()+ "：" + curGridBase.gDataDiscr[level].DMinute.ToString() + "\r\n经度：" +
                curGridBase.dWLon.ToString() + "---" + curGridBase.dELon.ToString() + "E\r\n纬度：" + curGridBase.dBLat.ToString() +
                "---" + curGridBase.dTLat.ToString() + "N\r\n分辨率：" + curGridBase.dCrossRes.ToString() + "\r\n" + txtDiscribe.Text;
        }

        /// <summary>
        /// 处理程序关闭事件
        /// </summary>
        private void btnReturn_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        /// <summary>
        /// 调入并显示当前数据上一个时次的数据和图
        /// </summary>
        private void btnLeft_Click(object sender, RoutedEventArgs e)
        {
            Cursor tmpMouse = Mouse.OverrideCursor;
            Mouse.OverrideCursor = Cursors.Wait;
            btnAnimation.IsEnabled = false;
            btnLeft.IsEnabled = false;
            btnReadFrom.IsEnabled = false;
            btnReturn.IsEnabled = false;
            btnRight.IsEnabled = false;
            txtDiscribe.Text = "请稍候！。。。。。。" + "\r\n" + txtDiscribe.Text;

            string fileNameTmp = (indexCurFile > 0) ? curPathFiles[indexCurFile - 1] : "";

            if (fileNameTmp != "")
            {
                indexCurFile--;

                FileInfo basefileinfo = new FileInfo(fileNameTmp);
                bool bReadOk = true;
                Object tmpObj;
                curGridBase = new CommonGridDat.CommonGridDat();
                if (basefileinfo.Exists)
                {
                    try
                    {
                        if (fileCompressID)
                        {
                            bReadOk = curGridBase.ReadFromCompressFile(ref fileNameTmp, out tmpObj);
                        }
                        else
                        {
                            bReadOk = curGridBase.ReadFromFile(ref fileNameTmp, out tmpObj);
                        }
                        curGridBase = (CommonGridDat.CommonGridDat)tmpObj;
                    }
                    catch (Exception ecpt)
                    {
                        txtDiscribe.Text = "数据文件导入出错，有可能数据分辨率不匹配。错误码：" + ecpt.Message + "\r\n" + txtDiscribe.Text;

                        Mouse.OverrideCursor = tmpMouse;
                        btnAnimation.IsEnabled = true;
                        btnLeft.IsEnabled = true;
                        btnReadFrom.IsEnabled = true;
                        btnReturn.IsEnabled = true;
                        btnRight.IsEnabled = true;
                        return;
                    }
                    ifGrid = false;         //刚读出来的数据肯定不带网格，因此要对此标志明确赋值。

                    int levelTmp = 0;
                    curGridBase.MakeTheLevelImage(ref levelTmp, out theBitmap);
                    bool bGrd = (bool)grdLine.IsChecked;
                    addGridSub(bGrd);
                }
                else
                {
                    txtDiscribe.Text = "选定文件有问题，失败！！！" + "\r\n" + txtDiscribe.Text;
                }
            }
            else
            {
                txtDiscribe.Text = "滚动到顶头儿啦！！！" + "\r\n" + txtDiscribe.Text;
            }

            Mouse.OverrideCursor = tmpMouse;
            btnAnimation.IsEnabled = true;
            btnLeft.IsEnabled = true;
            btnReadFrom.IsEnabled = true;
            btnReturn.IsEnabled = true;
            btnRight.IsEnabled = true;
        }

        /// <summary>
        /// 调入并显示当前数据下一个时次的数据和图
        /// </summary>
        private void btnRight_Click(object sender, RoutedEventArgs e)
        {
            Cursor tmpMouse = Mouse.OverrideCursor;
            Mouse.OverrideCursor = Cursors.Wait;
            btnAnimation.IsEnabled = false;
            btnLeft.IsEnabled = false;
            btnReadFrom.IsEnabled = false;
            btnReturn.IsEnabled = false;
            btnRight.IsEnabled = false;
            txtDiscribe.Text = "请稍候！。。。。。。" + "\r\n" + txtDiscribe.Text;

            string fileNameTmp = (indexCurFile < (curPathFiles.Count -1)) ? curPathFiles[indexCurFile + 1] : "";

            if (fileNameTmp != "")
            {
                indexCurFile++;

                FileInfo basefileinfo = new FileInfo(fileNameTmp);
                bool bReadOk = true;
                Object tmpObj;
                curGridBase = new CommonGridDat.CommonGridDat();
                if (basefileinfo.Exists)
                {
                    try
                    {
                        if (fileCompressID)
                        {
                            bReadOk = curGridBase.ReadFromCompressFile(ref fileNameTmp, out tmpObj);
                        }
                        else
                        {
                            bReadOk = curGridBase.ReadFromFile(ref fileNameTmp, out tmpObj);
                        }
                        curGridBase = (CommonGridDat.CommonGridDat)tmpObj;
                    }
                    catch (Exception ecpt)
                    {
                        txtDiscribe.Text = "数据文件导入出错，有可能数据分辨率不匹配。错误码：" + ecpt.Message + "\r\n" + txtDiscribe.Text;

                        Mouse.OverrideCursor = tmpMouse;
                        btnAnimation.IsEnabled = true;
                        btnLeft.IsEnabled = true;
                        btnReadFrom.IsEnabled = true;
                        btnReturn.IsEnabled = true;
                        btnRight.IsEnabled = true;
                        return;
                    }
                    ifGrid = false;         //刚读出来的数据肯定不带网格，因此要对此标志明确赋值。

                    int levelTmp = 0;
                    curGridBase.MakeTheLevelImage(ref levelTmp, out theBitmap);
                    bool bGrd = (bool)grdLine.IsChecked;
                    addGridSub(bGrd);
                }
                else
                {
                    txtDiscribe.Text = "选定文件有问题，失败！！！" + "\r\n" + txtDiscribe.Text;
                }
            }
            else
            {
                txtDiscribe.Text = "滚动到末尾啦！！！" + "\r\n" + txtDiscribe.Text;
            }

            Mouse.OverrideCursor = tmpMouse;
            btnAnimation.IsEnabled = true;
            btnLeft.IsEnabled = true;
            btnReadFrom.IsEnabled = true;
            btnReturn.IsEnabled = true;
            btnRight.IsEnabled = true;
        }

        /// <summary>
        /// 调入最近20个时次的数据和图，形成动画数据。
        /// </summary>
        private void btnAnimation_Click(object sender, RoutedEventArgs e)
        {
            if (bAnim)
                bAnim = false;
            else
            {
                bAnim = true;
                Cursor tmpMouse = Mouse.OverrideCursor;
                Mouse.OverrideCursor = Cursors.Wait;
                btnAnimation.IsEnabled = true;
                btnLeft.IsEnabled = false;
                btnReadFrom.IsEnabled = false;
                btnReturn.IsEnabled = false;
                btnRight.IsEnabled = false;
                txtDiscribe.Text = "正在动画！按动画键可终止。。。。。。" + "\r\n" + txtDiscribe.Text;

                bool brtn = loadAnimationImage();
                if (!brtn)
                {
                    Mouse.OverrideCursor = tmpMouse;
                    btnAnimation.IsEnabled = true;
                    btnLeft.IsEnabled = true;
                    btnReadFrom.IsEnabled = true;
                    btnReturn.IsEnabled = true;
                    btnRight.IsEnabled = true;
                    bAnim = false;
                    return;
                }

                txtDiscribe.Text = "用户启动了动画过程！" + "\r\n" + txtDiscribe.Text;
                animIndex = 0;
                dtAnimUpdate = DateTime.Now;
                timer.Start();
            }

            if (!bAnim)
            {
                timer.Stop();
                txtDiscribe.Text = "用户停止了动画过程！" + "\r\n" + txtDiscribe.Text;
                Mouse.OverrideCursor = Cursors.Arrow;
                btnAnimation.IsEnabled = true;
                btnLeft.IsEnabled = true;
                btnReadFrom.IsEnabled = true;
                btnReturn.IsEnabled = true;
                btnRight.IsEnabled = true;
                bAnim = false;

                bool bGrd = (bool)grdLine.IsChecked;
                addGridSub(bGrd);
                GC.Collect();
                GC.WaitForPendingFinalizers();
                return;
            }

        }

        /// <summary>
        /// 按照时钟触发执行类动画滚动显示。
        /// </summary>
        private void animationUpdate(object sender, EventArgs e)
        {
            DateTime dtTmp = DateTime.Now;
            TimeSpan tsTmp = dtTmp.Subtract(dtAnimUpdate);
            if (tsTmp.TotalMinutes > 15)
            {
                dtAnimUpdate = DateTime.Now;
                bool brtn = loadAnimationImage();
                if (!brtn)
                {
                    Mouse.OverrideCursor = Cursors.Arrow;
                    btnAnimation.IsEnabled = true;
                    btnLeft.IsEnabled = true;
                    btnReadFrom.IsEnabled = true;
                    btnReturn.IsEnabled = true;
                    btnRight.IsEnabled = true;
                    bAnim = false;
                    return;
                }
            }
            else
            {
                if (animNum > 0)
                {
                    new Thread(() =>
                    {
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            if (animIndex < animNum)
                            {
                                viewImg0.Source = thebmpSources[animIndex];
                                animIndex++;
                            }
                            else
                            {
                                animIndex = 0;
                                viewImg0.Source = thebmpSources[animIndex];
                                animIndex++;
                            }
                        }));
                    }).Start();
                }
            }
            DispatcherHelper.DoEvents();        //由于卫星数据文件较大，读入处理时间较长，在界面上给予提示并使窗口暂时失效以拒绝人机交互！
        }

        /// <summary>
        /// 这个子程序用于调入当前目录下最新的、最多二十幅图片，以备动画使用。其中最新的同时赋值给滚动显示图片，用于动画结束时的显示。
        /// </summary>
        /// <returns>如果装载图片过程顺利则返回true,否则返回false。</returns>
        private bool loadAnimationImage()
        {
            bool bRtn = true;
            /// <summary>定义了当前参与动画的数据图像</summary>
            theBitmaps = new Bitmap[20];
            /// <summary>设定相应参与动画的内存流，用于指向图像控件的源</summary>
            theBitmapStreams = new MemoryStream[20];
            /// <summary>相应参与动画的显示用图像源</summary>
            thebmpSources = new ImageSource[20];
            /// <summary>相应参与动画的显示用图像源转换格式</summary>
            theimgSourCons = new ImageSourceConverter[20];
            /// <summary>设定一个参与动画的经纬网格数据类</summary>
            CommonGridDat.CommonGridDat curGridAnimation;

            string[] thePathFiles = Directory.GetFiles(curDataPath);
            Array.Sort(thePathFiles);
            Match matchFilename;
            curPathFiles.Clear();
            foreach (string strFileName in thePathFiles)
            {
                matchFilename = regFileName.Match(strFileName);
                if (matchFilename.Success)
                {
                    curPathFiles.Add(strFileName);
                }
            }               //上面这一段将用户选定目录下的所有Grd文件名全部添加进当前文件名列表当中，以备来回滚动播放。

            int animB = (curPathFiles.Count > 20) ? curPathFiles.Count - 20 : 0;
            int animE = (curPathFiles.Count > 1) ? curPathFiles.Count : 0;
            string fileNameTmp = "";
            animNum = animE - animB;
            int imgIdx = animNum;
            for (int iz = animE - 1; iz >= animB; iz--)
            {
                fileNameTmp = curPathFiles[iz];
                imgIdx--;

                FileInfo basefileinfo = new FileInfo(fileNameTmp);
                bool bReadOk = true;
                Object tmpObj;
                curGridAnimation = new CommonGridDat.CommonGridDat();
                if (basefileinfo.Exists)
                {
                    try
                    {
                        if (fileCompressID)
                        {
                            bReadOk = curGridAnimation.ReadFromCompressFile(ref fileNameTmp, out tmpObj);
                        }
                        else
                        {
                            bReadOk = curGridAnimation.ReadFromFile(ref fileNameTmp, out tmpObj);
                        }
                        curGridAnimation = (CommonGridDat.CommonGridDat)tmpObj;
                        if (imgIdx == (animNum - 1))
                        {   //这一段同时把得到的tmpObj也赋值给了当前单幅显示的数据对象curGridBase。
                            IFormatter baseFormat = new BinaryFormatter();
                            Stream basestream = new MemoryStream();
                            baseFormat.Serialize(basestream, tmpObj);
                            basestream.Seek(0, 0);
                            curGridBase = (CommonGridDat.CommonGridDat)baseFormat.Deserialize(basestream);
                        }           //把时间最近的数据存起来作为动画停止后单幅显示的数据。
                    }
                    catch (Exception ecpt)
                    {
                        timer.Stop();
                        txtDiscribe.Text = "读入动画数据出错！！！" + ecpt.Message + "\r\n" + txtDiscribe.Text;
                        bRtn = false;
                        return bRtn;
                    }
                    ifGrid = false;         //刚读出来的数据肯定不带网格，因此要对此标志明确赋值。

                    int levelTmp = 0;
                    curGridAnimation.MakeTheLevelImage(ref levelTmp, out theBitmaps[imgIdx]);
                    bool bGrd = (bool)grdLine.IsChecked;
                    if (ifGrid != bGrd)
                    {                           //如果显示要求bGrd是要求带网格，则要对显示图进行加网格处理。
                        System.Drawing.Color coPix;
                        byte bpix;
                        int ixBegin = (int)curGridAnimation.dWLon;
                        int iyBegin = (int)curGridAnimation.dTLat;
                        int ixEnd = (int)curGridAnimation.dELon;
                        int iyEnd = (int)curGridAnimation.dBLat;
                        int iDifx = ixEnd - ixBegin;
                        int iDify = iyBegin - iyEnd;
                        int bmpHeight = theBitmaps[imgIdx].Height;
                        int bmpWidth = theBitmaps[imgIdx].Width;
                        double coeffx = bmpWidth / iDifx;
                        double coeffy = bmpHeight / iDify;
                        int iTmpX = 0;
                        int iTmpY = 0;
                        for (int iy = iyBegin; iy > iyEnd; iy--)
                        {
                            for (int ix = ixBegin; ix < ixEnd; ix++)
                            {
                                iTmpX = (int)((ix - ixBegin) * coeffx);
                                iTmpY = (int)((iyBegin - iy) * coeffy);
                                coPix = theBitmaps[imgIdx].GetPixel(iTmpX, iTmpY);
                                bpix = coPix.R;
                                if (bGrd)
                                    coPix = System.Drawing.Color.FromArgb(bpix, 0, bpix);
                                else
                                    coPix = System.Drawing.Color.FromArgb(bpix, bpix, bpix);
                                theBitmaps[imgIdx].SetPixel(iTmpX, iTmpY, coPix);
                            }
                        }
                    }
                    ifGrid = bGrd;          //图是否带网格标志在这里要确定。

                    try
                    {
                        theBitmapStreams[imgIdx] = new MemoryStream();
                        theimgSourCons[imgIdx] = new ImageSourceConverter();
                        theBitmaps[imgIdx].Save(theBitmapStreams[imgIdx], System.Drawing.Imaging.ImageFormat.Png);
                        thebmpSources[imgIdx] = (ImageSource)imgSourCon.ConvertFrom(theBitmapStreams[imgIdx]);
                    }
                    catch (Exception excp0)
                    {
                        txtDiscribe.Text = "准备图片意外！！！" + excp0.Message + "\r\n" + txtDiscribe.Text;
                        bRtn = false;
                    }
                }
                else
                {
                    timer.Stop();
                    txtDiscribe.Text = "读入动画数据文件出错！！！" + "\r\n" + txtDiscribe.Text;
                    bRtn = false;
                    return bRtn;
                }

            }
            theBitmap = theBitmaps[animNum - 1];    //这里把单幅显示的图设置成了动画图集中最近时间的图，为停止动画时的合理显示。

            return bRtn;
        }

    }

    /// <summary>
    /// 设定一个字符串类的变更通知触发，用于与显示控件绑定。
    /// </summary>
    class ViewTxt : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string txtStr;

        public string txtLongStr
        {
            get { return txtStr; }
            set
            {
                txtStr = value;
                if (this.PropertyChanged != null)
                {
                    this.PropertyChanged.Invoke(this, new PropertyChangedEventArgs("txtLongStr"));
                }
            }
        }
    }

    /// <summary>
    /// 这里设计了一个类似WindowsForm里的DoEvents的类，用于批量处理文件时避免界面假死机。
    /// </summary>
    public class DispatcherHelper
    {
        /// <summary>
        /// Simulate Application.DoEvents function of <see cref=" System.Windows.Forms.Application"/> class.
        /// </summary>
        [SecurityPermissionAttribute(SecurityAction.Demand, Flags = SecurityPermissionFlag.UnmanagedCode)]
        public static void DoEvents()
        {
            var frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);

            try
            {
                Dispatcher.PushFrame(frame);
            }
            catch (InvalidOperationException)
            {
            }
        }

        private static object ExitFrames(object frame)
        {
            ((DispatcherFrame)frame).Continue = false;
            return null;
        }
    }

}
