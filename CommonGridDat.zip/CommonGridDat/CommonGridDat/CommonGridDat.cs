﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

using System.IO;
using System.IO.Compression;                            //包含压缩流的函数
using System.Runtime.Serialization;                     //包含序列化函数
using System.Runtime.Serialization.Formatters.Binary;   //包含序列化格式化函数.


namespace CommonGridDat
{
    /// <summary>
    /// 定义一个结构用于描述多层经纬网格数据的某一层的数据识别，包括：数据描述字符串，年月日时分秒等。
    /// </summary>
    [Serializable]
    public class GridDiscr
    {
        /// <summary>多层经纬网格数据中本层的数据识别字符串，在使用中定义须不断规范</summary>
        public string DataDiscr;
        /// <summary>多层经纬网格数据中本层数据的小数位数，1为整数；10为一位小数；100为两位小数；1000为三位小数。 </summary>
        public int DecPlace;
        /// <summary>多层经纬网格数据中本层数据的生成年代</summary>
        public int DYear;
        /// <summary>多层经纬网格数据中本层数据的生成月份，如是年值，则本变量及以下值均为int.MaxValue</summary>
        public int DMounth;
        /// <summary>多层经纬网格数据中本层数据的生成日期，如是月值，则本变量及以下值均为int.MaxValue</summary>
        public int DDay;
        /// <summary>多层经纬网格数据中本层数据的生成时间，如是日值，则本变量及以下值均为int.MaxValue</summary>
        public int DTime;
        /// <summary>多层经纬网格数据中本层数据的生成分钟，如是小时值，则本变量及以下值均为int.MaxValue</summary>
        public int DMinute;
        /// <summary>多层经纬网格数据中本层数据的生成秒，如是分钟值，则本变量为int.MaxValue</summary>
        public int DSecond;
        /// <summary>本层除去无数据点以外的格点数据的均值,以int.MaxValue为无数据表示,下同。</summary>
        public int iMeanGrayValue;
        /// <summary>本层除去无数据点以外的格点数据的方差</summary>
        public int iVariance;
        /// <summary>本层除去无数据点以外的格点数据中的极大值</summary>
        public int iMaxValue;
        /// <summary>本层除去无数据点以外的格点数据中的极小值</summary>
        public int iMinimum;

        /// <summary>
        /// 多层网格数据中某一层数据识别参数的初始化，这里为了避免时分秒等数值参数识别歧义，无数据用int.MaxValue表达。
        /// </summary>
        public GridDiscr()
        {
            DataDiscr = "";
            DecPlace = 1;
            DYear = 2001;
            DMounth = 1;
            DDay = 1;
            DTime = 0;
            DMinute = 0;
            DSecond = 0;
            iMeanGrayValue = 0;         //层数据以灰度表示，灰度无负值，因此初始值以0初始。
            iVariance = 0;
            iMaxValue = 0;
            iMinimum = 0;
        }           //须初始化成一个合理的年月日，这里设定从2001年开始。
    }

    /// <summary>
    /// 这个数据类是表达了这样一个思想，即：设想一个均匀的经纬网格点，每个点上都有数据，
    /// 这个数据可以是一种或多种，多种数据用数据层来表达，从而形成了一个三维的数组。
    /// 这个数组的下标无疑表达了经纬等距点和数据的层，数组的值则表达了这个格点相应层的数据。
    /// 每个层的数据是什么意义，生成时间是什么，则表达进类中的层表达结构变量中，当然如果你自
    /// 己清楚不想表达，也不会影响你自己的使用。
    /// </summary>
    [Serializable]
    public class CommonGridDat
    {
        /// <summary>经纬网格区域上纬度</summary>
        public double dTLat;
        /// <summary>经纬网格区域下纬度</summary>
        public double dBLat;
        /// <summary>经纬网格区域左经度</summary>
        public double dWLon;
        /// <summary>经纬网格区域右经度</summary>
        public double dELon;
        /// <summary>经纬网格横向分辨率</summary>
        public double dCrossRes;
        /// <summary>经纬网格纵向分辨率</summary>
        public double dEndlongRes;
        /// <summary>经纬网格区域对应的横向数据点数</summary>
        public int iPixX;
        /// <summary>经纬网格区域对应的纵向数据点数</summary>
        public int iPixY;
        /// <summary>经纬网格的数据层数</summary>
        public int iGridLevel;
        /// <summary>用于描述多层经纬网格数据的每一层的数据识别，包括：数据描述字符串，年月日时分秒等。</summary>
        public GridDiscr[] gDataDiscr;
        /// <summary>表达经纬网格及其相应数据的三维数组</summary>
        public int[,,] iLLGrid;

        /// <summary>
        /// 以默认方式实例化这个经纬网格，纬度范围30—50，经度范围70—100，分辨率横纵皆为1/32度；
        /// 数据层为2层。大约是960*640*2的格点阵。
        /// </summary>
        public CommonGridDat()
        {
            this.dTLat = 50.0;
            this.dBLat = 30.0;
            this.dWLon = 70.0;
            this.dELon = 100.0;
            this.dCrossRes = 1.0 / 32.0;
            this.dEndlongRes = 1.0 / 32.0;
            this.iGridLevel = 2;
            gDataDiscr = new GridDiscr[iGridLevel];
            for (int ix = 0; ix < iGridLevel; ix++)
            {
                gDataDiscr[ix] = new GridDiscr();
            }
            iPixX = (int)((dELon - dWLon) / dCrossRes);
            iPixY = (int)((dTLat - dBLat) / dEndlongRes);
            iLLGrid = new int[iPixY, iPixX, 2];
        }

        /// <summary>
        /// 以调用参数化方式实例化这个经纬网格。返回的实例如果层数小于0，则未成功实例化。
        /// </summary>
        public CommonGridDat(ref double dTLat, ref double dBLat, ref double dWLon, ref double dELon,
            ref double dCrossRes, ref double dEndlongRes, ref int iGridLevel)
        {
            if ((dTLat <= dBLat) || (dELon <= dWLon) || (dCrossRes > 1) || (dEndlongRes > 1) || (iGridLevel < 1)
                || (iGridLevel > 10) || (dCrossRes <= 0) || (dWLon < 30))
            {
                iGridLevel = -1;            //这里规定了如果实例化输入参数不合逻辑，则以层数小于0的方式表达未成功实例化。
                return;
            }
            this.dTLat = dTLat;
            this.dBLat = dBLat;
            this.dWLon = dWLon;
            this.dELon = dELon;
            this.dCrossRes = dCrossRes;
            this.dEndlongRes = dEndlongRes;
            this.iGridLevel = iGridLevel;
            gDataDiscr = new GridDiscr[iGridLevel];
            for (int ix = 0; ix < iGridLevel; ix++)
            {
                gDataDiscr[ix] = new GridDiscr();
            }
            iPixX = (int)((dELon - dWLon) / dCrossRes);
            iPixY = (int)((dTLat - dBLat) / dEndlongRes);
            iLLGrid = new int[iPixY, iPixX, iGridLevel];
        }

        ///<summary>
        ///在本类实例化后，自行计算各层统计特征并实例化本类相应的统计量成员。
        ///</summary>
        public void LookForStatistic()
        {
            if ((iGridLevel > 0) && (iPixX > 0) && (iPixY > 0))
            {
                int iEave, iDevi, iMax, iMin, iCnt;
                long iSum;                          //这里原来是个错误，iSum如果是int，可能造成求方差时，求算样本平方时溢出。
                for (int izz = 0; izz < iGridLevel; izz++)
                {
                    iCnt = 0;
                    iSum = 0;
                    iMax = 0;
                    iMin = int.MaxValue;
                    iEave = 0;
                    iDevi = 0;
                    for (int iyy = 0; iyy < iPixY; iyy++)
                    {
                        for (int ixx = 0; ixx < iPixX; ixx++)
                        {
                            if ((iLLGrid[iyy, ixx, izz] != int.MaxValue) && (iLLGrid[iyy, ixx, izz] != 0))
                            {
                                iSum += iLLGrid[iyy, ixx, izz];
                                iCnt++;
                                iMax = (iMax < iLLGrid[iyy, ixx, izz]) ? iLLGrid[iyy, ixx, izz] : iMax;
                                iMin = (iMin > iLLGrid[iyy, ixx, izz]) ? iLLGrid[iyy, ixx, izz] : iMin;
                            }
                        }
                    }
                    if (iCnt > 0)
                    {
                        iEave = (int)((double)iSum / (double)iCnt + 0.5);
                        iCnt = 0;
                        iSum = 0;
                        for (int iyy = 0; iyy < iPixY; iyy++)
                        {
                            for (int ixx = 0; ixx < iPixX; ixx++)
                            {
                                if ((iLLGrid[iyy, ixx, izz] != int.MaxValue) && (iLLGrid[iyy, ixx, izz] != 0))
                                {
                                    iSum += (iLLGrid[iyy, ixx, izz] - iEave) * (iLLGrid[iyy, ixx, izz] - iEave);
                                    iCnt++;
                                }
                            }
                        }
                        iDevi = (int)((double)iSum / (double)(iCnt - 1) + 0.5);
                    }
                    else
                    {
                        iEave = 0;
                        iDevi = 0;
                        iMax = 0;
                        iMin = 0;
                    }
                    this.gDataDiscr[izz].iMeanGrayValue = iEave;
                    this.gDataDiscr[izz].iVariance = iDevi;
                    this.gDataDiscr[izz].iMaxValue = iMax;
                    this.gDataDiscr[izz].iMinimum = iMin;
                }
            }

        }

        ///<summary>
        ///将本类某层数据用图像方式表达并提供(重载函数1)。
        ///</summary>
        ///<param name="iLevelN">打算显示图像用那一层的数据，如果不成功这个值将返回int.MaxValue值</param>
        ///<param name="levelBitmap">返回所要的图像</param>
        public void MakeTheLevelImage(ref int iLevelN, out Bitmap levelBitmap)
        {
            //Color coPixel;
            byte bPixel;
            levelBitmap = new Bitmap(iPixX, iPixY, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

            if ((iLevelN > iGridLevel) || (iLevelN < 0))
            {
                iLevelN = int.MaxValue;
                return;
            }
            if (gDataDiscr[iLevelN].DataDiscr.IndexOf(@"Gray") >= 0)    // || (gDataDiscr[iLevelN].DataDiscr.IndexOf(@"Zenith") >= 0))  //测试用代码
            {
                int theMax = gDataDiscr[iLevelN].iMaxValue;
                int theMin = gDataDiscr[iLevelN].iMinimum;
                double coeffGray = (theMax - theMin) / 255.0;    //上面这一段很重要，它将图像灰度有效利用到了最大值与最小值之间，
                int itmp = int.MaxValue;                         //从而在保证灰度层级的基础上最大限度提高了图像的对比度。

                //由于图像像素赋值太费时间，采用了unsafe代码，用指针寻址访问像素，以提高速度。
                System.Drawing.Imaging.BitmapData objData = levelBitmap.LockBits(new Rectangle(new Point(0, 0), new Size(iPixX, iPixY)),
                    System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                unsafe
                {
                    byte* bTmp = (byte*)objData.Scan0;
                    for (int iy = 0; iy < iPixY; iy++)
                    {
                        int lineoff = iy * objData.Stride;          //为了速度一个乘法都不让重复！哈哈！
                        for (int ix = 0; ix < iPixX; ix++)
                        {
                            itmp = this.iLLGrid[iy, ix, iLevelN];
                            if ((itmp < 0) || (itmp == int.MaxValue))
                            {
                                bPixel = 0;
                            }
                            else
                            {
                                itmp = (int)((itmp - theMin) / coeffGray);
                                bPixel = (byte)itmp;
                            }
                            int offset = lineoff + ix * 3;
                            //coPixel = Color.FromArgb(bPixel, bPixel, bPixel);
                            //levelBitmap.SetPixel(ix, iy, coPixel);
                            bTmp[offset] = bPixel;
                            bTmp[offset + 1] = bPixel;
                            bTmp[offset + 2] = bPixel;
                        }
                    }
                }
                levelBitmap.UnlockBits(objData);
            }
            else
            {
                iLevelN = int.MaxValue;
                return;
            }

        }

        /// <summary>
        /// 将本类某层数据的截取区域用图像方式表达并提供(重载函数2)。
        /// </summary>
        /// <param name="iLevelN">打算显示图像用那一层的数据，如果不成功这个值将返回int.MaxValue值</param>
        /// <param name="dleft">截取区域西经度</param>
        /// <param name="dright">截取区域东经度</param>
        /// <param name="dbottom">截取区域南纬度</param>
        /// <param name="dtop">截取区域北纬度</param>
        /// <param name="levelBitmap">返回所要的图像</param>
        public void MakeTheLevelImage(ref int iLevelN, double dleft,double dright,double dbottom,double dtop,out Bitmap levelBitmap)
        {
            byte bPixel;
            bool rationality = (iLevelN < iGridLevel) && (dleft >= dWLon) && (dright <= dELon) && (dright > dleft) && (dbottom >= dBLat) && (dtop <= dTLat)
                && (dtop > dbottom) && (gDataDiscr[iLevelN].DataDiscr.Contains("Gray"));    //参数合规性检查，要求：在经纬区域内、数据层号合理并且数据是灰度数据。
            if (rationality)
            {
                int theMax = gDataDiscr[iLevelN].iMaxValue;
                int theMin = gDataDiscr[iLevelN].iMinimum;
                double coeffGray = (theMax - theMin) / 255.0;    //上面这一段很重要，它将图像灰度有效利用到了最大值与最小值之间，
                int itmp = int.MaxValue;                         //从而在保证灰度层级的基础上最大限度提高了图像的对比度。

                int iL = (int)((dleft - dWLon) / dCrossRes);    //图像横向起始点列号。
                int iR = iPixX - (int)((dELon - dright) / dCrossRes);   //图像横向截止点列号。
                int iT = (int)((dTLat - dtop) / dEndlongRes);           //图像纵向起始点行号，注意：图像行号是从上向下数的！
                int iB = iPixY - (int)((dbottom - dBLat) / dEndlongRes);    //图像纵向截止点行号，注意：图像行号是从上向下数的！
                int mapW = iR - iL;
                int mapH = iB - iT;         //确定输出图像的宽和高(像素)。
                levelBitmap = new Bitmap(mapW, mapH, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                //由于图像像素赋值太费时间，采用了unsafe代码，用指针寻址访问像素，以提高速度。
                System.Drawing.Imaging.BitmapData objData = levelBitmap.LockBits(new Rectangle(new Point(0, 0), new Size(mapW, mapH)),
                    System.Drawing.Imaging.ImageLockMode.ReadWrite, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                unsafe
                {
                    byte* bTmp = (byte*)objData.Scan0;
                    for (int iy = iT; iy < iB; iy++)
                    {
                        int lineoff = iy - iT;
                        lineoff = lineoff * objData.Stride;          //为了速度一个乘法都不让重复！哈哈！
                        for (int ix = iL; ix < iR; ix++)
                        {
                            itmp = this.iLLGrid[iy, ix, iLevelN];
                            if ((itmp < 0) || (itmp == int.MaxValue))
                            {
                                bPixel = 0;
                            }
                            else
                            {
                                itmp = (int)((itmp - theMin) / coeffGray);
                                bPixel = (byte)itmp;
                            }
                            int offset = ix - iL;
                            offset = lineoff + offset * 3;
                            //coPixel = Color.FromArgb(bPixel, bPixel, bPixel);
                            //levelBitmap.SetPixel(ix, iy, coPixel);
                            bTmp[offset] = bPixel;
                            bTmp[offset + 1] = bPixel;
                            bTmp[offset + 2] = bPixel;
                        }
                    }
                }
                levelBitmap.UnlockBits(objData);
            }
            else
            {
                iLevelN = int.MaxValue;
                levelBitmap = null;
            }
        }

        /// <summary>
        /// 将本经纬网格数据类的实例以流形式存储到指定路径。这个例程同时提供了类实例序列化的范例。
        /// </summary>
        /// <param name="filePath">给定的要存储的文件的全路径名，如果不成功，返回时将装入错误识别字符串。</param>
        /// <returns>存储到文件的操作是否成功，成功则返回true</returns>
        public bool SaveToFile(ref string filePath)
        {
            bool bRet = true;
            string saveFileName = filePath;

            try
            {
                IFormatter theDatFormat = new BinaryFormatter();        //定义一个序列化
                Stream theDatstream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None);  //打开文件流
                theDatFormat.Serialize(theDatstream, this);     //将this即本类实例序列化进文件流中。保存当前数据文件。
                theDatstream.Close();
                theDatstream.Dispose();       //关闭并释放流资源。
            }
            catch (Exception ecpt)
            {
                saveFileName = ecpt.Message;
                bRet = false;
                return bRet;
            }

            return bRet;
        }

        /// <summary>
        /// 将本经纬网格数据类的实例从存储的数据文件中读回来。这实际上是提供了一个以反序列化方式初始化类实例的方式。
        /// </summary>
        /// <param name="filePath">反序列化的类实例数据源文件全路径，如果不成功，返回时将装入错误识别字符串。</param>
        /// <param name="thisObj">反序列化后暂存的泛型对象</param>
        /// <returns>反序列化是否成功标志</returns>
        public bool ReadFromFile(ref string filePath, out object thisObj)
        {
            bool bRet = true;
            string readFileName = filePath;

            FileInfo basefileinfo = new FileInfo(readFileName);     //定义这个fileinfo纯粹为了辨识文件是否存在，避免意外。
            IFormatter baseFormat = new BinaryFormatter();        //定义一个序列化
            Stream basestream;
            if (basefileinfo.Exists)
            {
                try
                {
                    basestream = new FileStream(readFileName, FileMode.Open, FileAccess.Read, FileShare.Read);  //打开文件流
                    thisObj = baseFormat.Deserialize(basestream);   //将来自文件的数据流反序列化为一个泛型对象，可随即通过强制类型转换为本类实例。
                    basestream.Close();
                    basestream.Dispose();       //关闭并释放资源。
                }
                catch (Exception ecpt)
                {
                    readFileName = ecpt.Message;
                    bRet = false;
                    thisObj = null;
                    return bRet;
                }
            }
            else
            {
                bRet = false;
                thisObj = null;
            }

            return bRet;

        }

        /// <summary>
        /// 将本经纬网格数据类的实例以压缩流形式存储到指定路径。这个例程同时提供了类实例以压缩流序列化到数据文件的范例。
        /// </summary>
        /// <param name="compressFilePath">给定的要存储压缩流的文件的全路径名，如果不成功，返回时将装入错误识别字符串。</param>
        /// <returns>存储到文件的操作是否成功，成功则返回true</returns>
        public bool SaveToCompressFile(ref string compressFilePath)
        {
            bool bRet = true;
            string fileName = compressFilePath;

            try
            {
                MemoryStream msTmp = new MemoryStream();            //定义一个内存流，以便存储待压缩的本类实例序列化的数据流。
                IFormatter theDatFormat = new BinaryFormatter();    //定义一个序列化
                theDatFormat.Serialize(msTmp, this);                //将本类实例序列化并暂存在上面定义的内存流中，等待压缩并转存文件。
                byte[] bytesTmp = msTmp.GetBuffer();    //用一个字节流指针接过上面的内存流，这是因为压缩流仅能吃进字节流类型。
                Stream theDatstream = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None);  //打开文件流
                GZipStream theZipStream = new GZipStream(theDatstream, CompressionMode.Compress);   //定义压缩流并与上述文件流关联。
                theZipStream.Write(bytesTmp, 0, (int)msTmp.Length);     //将待压缩转存的字节流压缩并写入文件流。这里特别注意：不能用bytesTmp的长度！
                                                                        //bytesTmp的长度是msTmp的Capacity！
                msTmp.Close();
                msTmp.Dispose();                //关闭所打开的流们，并释放其占用资源。
                theZipStream.Close();
                theZipStream.Dispose();
                theDatstream.Close();
                theDatstream.Dispose();
            }
            catch (Exception ecpt)
            {
                fileName = ecpt.Message;
                bRet = false;
                return bRet;
            }

            return bRet;
        }

        /// <summary>
        /// 将本经纬网格数据类的实例从存储的压缩数据文件中读回来。这实际上是提供了一个以压缩流反序列化方式初始化类实例的方式。
        /// </summary>
        /// <param name="filePath">以压缩流形式存在的反序列化的类实例数据源文件全路径，如果不成功，返回时将装入错误识别字符串。</param>
        /// <param name="thisObj">反序列化后暂存的泛型对象</param>
        /// <returns>反序列化是否成功标志</returns>
        public bool ReadFromCompressFile(ref string filePath, out object thisObj)
        {
            bool bRet = true;
            string readFileName = filePath;

            FileInfo basefileinfo = new FileInfo(readFileName);
            if (basefileinfo.Exists)
            {
                try
                {
                    MemoryStream msTmp = new MemoryStream();            //定义一个内存流，以便存储解压缩后待反序列化的数据流。
                    IFormatter theDatFormat = new BinaryFormatter();    //定义一个序列化
                    Stream theDatstream = new FileStream(readFileName, FileMode.Open, FileAccess.Read, FileShare.Read);  //打开文件流
                    GZipStream theZipStream = new GZipStream(theDatstream, CompressionMode.Decompress);   //定义解压缩流并与上述文件流关联。
                    byte[] buffer = new byte[4096];         //定义一个字节数组作为读入缓冲区，一般硬盘存储以4096为一个最小单位。
                    int offset = 0;
                    while ((offset = theZipStream.Read(buffer,0,buffer.Length)) != 0)
                    {
                        msTmp.Write(buffer, 0, offset);     //循环读入并解压缩至暂存内存流中，直至读到文件末尾。
                    }
                    msTmp.Position = 0;
                    thisObj = theDatFormat.Deserialize(msTmp);      //反序列化为一个泛型对象，以便随后通过强制类型转化为本类实例。

                    msTmp.Close();
                    msTmp.Dispose();                //关闭所打开的流们，并释放其占用资源。
                    theZipStream.Close();
                    theZipStream.Dispose();
                    theDatstream.Close();
                    theDatstream.Dispose();
                }
                catch (Exception ecpt)
                {
                    readFileName = ecpt.Message;
                    thisObj = null;
                    bRet = false;
                }
            }
            else
            {
                thisObj = null;
                bRet = false;
                return bRet;
            }

            return bRet;
        }

        /// <summary>
        /// 这个函数用于读取本类每个层的描述字符串，以便用户方便查阅每层数据的意义。
        /// </summary>
        /// <returns>包含所有层的描述字符串数组</returns>
        public string[] GetLevelsDescribe()
        {
            if (iGridLevel > 0)
            {
                string[] strRet = new string[iGridLevel];
                for (int ix = 0; ix < iGridLevel; ix++)
                {
                    strRet[ix] = gDataDiscr[ix].DataDiscr;
                }
                return strRet;
            }
            else
            {
                string[] strRet = null;
                return strRet;
            }
        }

        /// <summary>
        /// 这个函数用于读取本类每个层的数据表达的时间，以便用户方便查阅每层数据的时间。
        /// </summary>
        /// <returns>包含所有层的时间数组</returns>
        public DateTime[] GetLevelsDatetime()
        {
            if (iGridLevel > 0)
            {
                DateTime[] dtRet = new DateTime[iGridLevel];
                for (int ix = 0; ix < iGridLevel; ix++)
                {
                    dtRet[ix] = new DateTime(gDataDiscr[ix].DYear, gDataDiscr[ix].DMounth, gDataDiscr[ix].DDay,
                        gDataDiscr[ix].DTime, gDataDiscr[ix].DMinute, gDataDiscr[ix].DSecond);
                }
                return dtRet;
            }
            else
            {
                DateTime[] dtRet = null;
                return dtRet;
            }
        }

        /// <summary>
        /// 获取给定经纬度对应点各数据层的数据。返回数据是通过靠近格点双线性插值后获得的值。
        /// </summary>
        /// <param name="pLon">给定经度</param>
        /// <param name="pLat">给定纬度</param>
        /// <returns>一个整型数组，对应每个数据层，其值是靠近格点值双线性插值获得值</returns>
        public int[] GetPointValues(ref double pLon, ref double pLat)
        {
            bool rationality = (iGridLevel > 0) && (pLon >= dWLon) && (pLon <= dELon) && (pLat >= dBLat) && (pLat <= dTLat);    //参数合规性检查。
            if (rationality)
            {
                int[] valuesRet = new int[iGridLevel];
                double dcol = (pLon - dWLon) / dCrossRes;
                int iL = (int)(dcol);           //对应所要经纬点或其西边最靠近像素的列号。
                int iR = (int)(dcol + 0.5);     //对应所要经纬点或其东边最靠近像素的列号。
                double residCol = dcol - iL;    //是求列号时的余数，也是差值计算时的比例啊！
                double drow = (dTLat - pLat) / dEndlongRes;
                int iT = (int)(drow);           //对应所要经纬点或其北边最靠近像素的行号。
                int iB = (int)(drow + 0.5);     //对应所要经纬点或其南边最靠近像素的行号。
                double residRow = drow - iT;    //是求行号时的余数，也是差值计算时的比例啊！
                for (int ix = 0; ix < iGridLevel; ix++)
                {
                    int p00 = this.iLLGrid[iT, iL, ix];
                    int p01 = this.iLLGrid[iT, iR, ix];
                    int p10 = this.iLLGrid[iB, iL, ix];
                    int p11 = this.iLLGrid[iB, iR, ix];
                    double valueTmp = (p00 * (1 - residCol) + p01 * residCol) * (1 - residRow) + (p10 * (1 - residCol) + p11 * residCol) * residRow;
                    valuesRet[ix] = (int)(valueTmp + 0.5);
                }
                return valuesRet;
            }
            else
            {
                int[] valuesRet = null;
                return valuesRet;
            }
        }
    }
}
